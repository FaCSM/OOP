#ifndef OOP_NUMBER_H
#define OOP_NUMBER_H

#include "rational.h"

typedef TRational number;

#endif //OOP_NUMBER_H
